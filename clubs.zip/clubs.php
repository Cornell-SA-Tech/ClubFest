<?php session_start(); ?>
<!doctype html> 
<html> 
<head> 
    <meta charset="UTF-8">
    <title>CLUBFEST</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
<!--- uncomment for php login> 
require_once 'config.php';
$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
$Uuid = filter_input(INPUT_POST, 'uid', FILTER_SANITIZE_STRING);
$Upw = filter_input(INPUT_POST, 'pw', FILTER_SANITIZE_STRING);
$result = $mysqli->query("SELECT * FROM admin WHERE uId = '$Uuid'");
	$row = $result->fetch_assoc();
	$dbhash = $row['hashPw'];
	$dbuser = $row['uId'];
	if( password_verify($Upw, $dbhash)){
		$_SESSION['active'] = $dbuser;
		}
?> -->

<nav class="nav">
<img src='logo.png' title='Cornell Clubfest' alt='Cornell Clubfest'>
<form method='POST' name='search'><input type='text'></form> 
<ul>
<li><a href='index.php' title='ABOUT'>ABOUT</a></li>
<li><a href='clubs.php' class='active' title='CLUBS'>CLUBS</a></li>
<!---should be looped from SQL if they want to change the categories, but hardcoding here for mockup-->
<form method='POST' id='catergories'>
Community Service<input type="checkbox" name="cat" value="community"><br>
Religion<input type="checkbox" name="cat" value="religion"><br>
Social Change<input type="checkbox" name="cat" value="social"><br>
Performing Arts<input type="checkbox" name="cat" value="performing"><br>
Event Planning/Publication<input type="checkbox" name="cat" value="event"><br>
Buisiness/Career<input type="checkbox" name="cat" value="buisiness"><br>
Cultural<input type="checkbox" name="cat" value="cultural"><br>
Special Interest<input type="checkbox" name="cat" value="special"><br>
Science/Technology<input type="checkbox" name="cat" value="science"><br>
</form>
<li><a href='contact.php' title='CONTACT'>CONTACT</a></li>
</ul>
</nav>

</body>
</html>