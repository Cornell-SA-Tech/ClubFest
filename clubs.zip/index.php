<?php session_start(); ?>
<!doctype html> 
<html> 
<head> 
    <meta charset="UTF-8">
    <title>CLUBFEST</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
<!--- uncomment for php login> 
require_once 'config.php';
$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
$Uuid = filter_input(INPUT_POST, 'uid', FILTER_SANITIZE_STRING);
$Upw = filter_input(INPUT_POST, 'pw', FILTER_SANITIZE_STRING);
$result = $mysqli->query("SELECT * FROM admin WHERE uId = '$Uuid'");
	$row = $result->fetch_assoc();
	$dbhash = $row['hashPw'];
	$dbuser = $row['uId'];
	if( password_verify($Upw, $dbhash)){
		$_SESSION['active'] = $dbuser;
		}
?> -->

<nav class="nav">
<img src='logo.png' title='Cornell Clubfest' alt='Cornell Clubfest'>
<form method='POST' id= 'search' name='search'><input type='text'></form> 
<ul>
<li><a href='index.php' class='active' title='ABOUT'>ABOUT</a></li>
<li><a href='clubs.php' title='CLUBS'>CLUBS</a></li>
<li><a href='contact.php' title='CONTACT'>CONTACT</a></li>
</ul>
</nav>

</body>
</html>